import sys
import os
import shutil
import webbrowser
import random
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QLabel, QPushButton, QFrame, 
                             QStackedWidget, QDialog, QGraphicsDropShadowEffect,
                             QSizePolicy, QSpacerItem,QProgressBar)
from PyQt5.QtCore import Qt, QTimer, QPoint, QRectF, QRect
from PyQt5.QtGui import (QFont, QColor, QPainter, QBrush, QPen, QIcon, QPixmap, 
                         QRadialGradient, QPainterPath, QLinearGradient)
import pygame

# =============================================================================
# --- CONFIGURATION ---
# =============================================================================
CONFIG = {
    "GAME_NAME": "Beach Buggy Racing",
    "GAME_PACKAGE_ID": "VectorUnit.BeachBuggyRacing_hvbhrzr8672s2",
    "FOLDERS_TO_COPY": ["LocalState"], 
    "MS_STORE_LINK": "https://apps.microsoft.com/detail/9WZDNCRDV0L0?hl=en&gl=US&ocid=pdpshare",
    "GITHUB_LINK": "https://github.com/boyoftime/MS-PATCHER/releases",
    "DONATE_LINK": "https://nowpayments.io/donation/someless",
    "PATCH_FEATURES": [
        "Unlimited Coins,tickets & Diamonds",
        "Unlocked Cars,Levels,Drivers and more",
        "Split screen mode Unlocked",
    ]
}

# --- STYLING CONSTANTS ---
BG_COLOR = "#0A0A0A"
FG_COLOR = "#00FF41"      # Matrix Green
ACCENT_COLOR = "#39FF14"  # Brighter Green
TEXT_WHITE = "#EAEAEA"
TEXT_DIM = "#888888"
RED_COLOR = "#FF4136"

# --- GLOBAL STYLESHEET ---
STYLESHEET = f"""
QMainWindow {{
    background-color: {BG_COLOR};
}}
QDialog {{
    background-color: {BG_COLOR};
    border: 1px solid {FG_COLOR};
}}
QLabel {{
    color: {TEXT_WHITE};
    font-family: 'Quicksand', 'Segoe UI', sans-serif;
}}
QPushButton {{
    border: 2px solid {FG_COLOR};
    color: {FG_COLOR};
    background-color: transparent;
    border-radius: 15px;
    font-family: 'Quicksand', 'Segoe UI', sans-serif;
    font-weight: bold;
    font-size: 14px;
    padding: 5px;
}}
QPushButton:hover {{
    background-color: {FG_COLOR};
    color: {BG_COLOR};
}}
QPushButton:pressed {{
    background-color: {ACCENT_COLOR};
    border-color: {ACCENT_COLOR};
}}
/* Main Patch Button */
QPushButton#PatchButton {{
    background-color: {FG_COLOR};
    color: {BG_COLOR};
    border-radius: 30px;
    font-size: 22px;
    border: none;
    font-weight: 800;
}}
QPushButton#PatchButton:hover {{
    background-color: {ACCENT_COLOR};
}}
/* Secondary Buttons (Footer) */
QPushButton#FooterButton {{
    border: 1px solid {FG_COLOR};
    border-radius: 20px;
}}
"""

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# =============================================================================
# --- CUSTOM VISUAL WIDGETS ---
# =============================================================================

class VolumeButton(QPushButton):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(40, 40)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet("border: none; background: transparent;")
        self.muted = False

    def set_muted(self, state):
        self.muted = state
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        color = QColor(TEXT_WHITE) if self.underMouse() else QColor(TEXT_DIM)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(color))

        path = QPainterPath()
        path.moveTo(10, 14)
        path.lineTo(16, 14)
        path.lineTo(24, 8)
        path.lineTo(24, 32)
        path.lineTo(16, 26)
        path.lineTo(10, 26)
        path.closeSubpath()
        painter.drawPath(path)

        painter.setPen(QPen(color, 2, Qt.SolidLine, Qt.RoundCap))
        painter.setBrush(Qt.NoBrush)

        if self.muted:
            painter.drawLine(28, 16, 34, 24)
            painter.drawLine(34, 16, 28, 24)
        else:
            painter.drawArc(QRectF(16, 12, 16, 16), -45 * 16, 90 * 16)
            painter.drawArc(QRectF(14, 8, 24, 24), -45 * 16, 90 * 16)

class FadedImageLabel(QWidget):
    def __init__(self, image_path, parent=None):
        super().__init__(parent)
        self.pixmap = None
        self.setFixedHeight(280) # Your custom height
        
        if os.path.exists(image_path):
            self.pixmap = QPixmap(image_path)
        else:
            self.pixmap = QPixmap(300, 200)
            self.pixmap.fill(QColor("#1a1a1a"))

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)

        if not self.pixmap: return

        w, h = self.width(), self.height()

        # 1. DRAW IMAGE (Full width/Back style)
        img_pix = self.pixmap.scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        x = (w - img_pix.width()) // 2
        y = (h - img_pix.height()) // 2
        painter.drawPixmap(x, y, img_pix)

        # 2. APPLY FADE EFFECTS (All 4 sides)
        bg_col = QColor(BG_COLOR)
        transparent = QColor(BG_COLOR)
        transparent.setAlpha(0)

        # Define how big the fades are
        fade_height = 40 
        fade_width = 50

        # --- TOP FADE (New) ---
        grad_top = QLinearGradient(0, 0, 0, fade_height)
        grad_top.setColorAt(0, bg_col)       # Solid black at very top
        grad_top.setColorAt(1, transparent)  # Fades to transparent going down
        painter.fillRect(0, 0, w, fade_height, grad_top)

        # --- BOTTOM FADE ---
        grad_bot = QLinearGradient(0, h, 0, h - fade_height)
        grad_bot.setColorAt(0, bg_col)       # Solid black at very bottom
        grad_bot.setColorAt(1, transparent)  # Fades to transparent going up
        painter.fillRect(0, h - fade_height, w, fade_height, grad_bot)

        # --- LEFT FADE ---
        grad_left = QLinearGradient(0, 0, fade_width, 0)
        grad_left.setColorAt(0, bg_col)
        grad_left.setColorAt(1, transparent)
        painter.fillRect(0, 0, fade_width, h, grad_left)

        # --- RIGHT FADE ---
        grad_right = QLinearGradient(w, 0, w - fade_width, 0)
        grad_right.setColorAt(0, bg_col)
        grad_right.setColorAt(1, transparent)
        painter.fillRect(w - fade_width, 0, fade_width, h, grad_right)

class ModernDialog(QDialog):
    def __init__(self, title, message, parent=None, is_error=False):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setFixedSize(450, 250)
        self.setWindowFlags(Qt.Dialog | Qt.CustomizeWindowHint | Qt.WindowTitleHint)
        layout = QVBoxLayout()
        layout.setContentsMargins(30, 30, 30, 30)
        self.setLayout(layout)
        lbl_msg = QLabel(message)
        lbl_msg.setWordWrap(True)
        lbl_msg.setAlignment(Qt.AlignCenter)
        lbl_msg.setStyleSheet(f"font-size: 12pt; color: {RED_COLOR if is_error else TEXT_WHITE};")
        layout.addWidget(lbl_msg)
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(20)
        self.btn_ok = QPushButton("PROCEED" if not is_error else "DOWNLOAD")
        self.btn_ok.setFixedSize(140, 45)
        self.btn_ok.setCursor(Qt.PointingHandCursor)
        self.btn_ok.clicked.connect(self.accept)
        self.btn_cancel = QPushButton("CANCEL" if not is_error else "CLOSE")
        self.btn_cancel.setStyleSheet(f"border-color: {RED_COLOR}; color: {RED_COLOR};")
        self.btn_cancel.setFixedSize(140, 45)
        self.btn_cancel.setCursor(Qt.PointingHandCursor)
        self.btn_cancel.clicked.connect(self.reject)
        btn_layout.addWidget(self.btn_ok)
        btn_layout.addWidget(self.btn_cancel)
        layout.addStretch()
        layout.addLayout(btn_layout)

class ParticleWidget(QWidget):
    class Spark:
        def __init__(self, w, h):
            self.x, self.y = w / 2, h / 2
            self.vx, self.vy = random.uniform(-2, 2), random.uniform(-2, 2)
            self.size = random.randint(2, 5)
            self.color = random.choice([FG_COLOR, ACCENT_COLOR, "#00FFFF", "#FFFFFF"])
            self.life = 255
    def __init__(self, parent=None):
        super().__init__(parent)
        self.particles = []
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_particles)
        path = resource_path('rocket.png')
        self.rocket_pixmap = QPixmap(path).scaled(128, 128, Qt.KeepAspectRatio, Qt.SmoothTransformation) if os.path.exists(path) else None
    def start_animation(self):
        self.particles = []
        self.timer.start(16)
    def update_particles(self):
        if len(self.particles) < 100: self.particles.append(self.Spark(self.width(), self.height()))
        for p in self.particles:
            p.x += p.vx; p.y += p.vy; p.life -= 4
        self.particles = [p for p in self.particles if p.life > 0]
        self.update()
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        if self.rocket_pixmap:
            x, y = (self.width() - self.rocket_pixmap.width()) // 2, (self.height() - self.rocket_pixmap.height()) // 2 - 50
            painter.drawPixmap(x, y, self.rocket_pixmap)
        for p in self.particles:
            c = QColor(p.color); c.setAlpha(max(0, p.life))
            painter.setBrush(QBrush(c)); painter.setPen(Qt.NoPen)
            painter.drawEllipse(QPoint(int(p.x), int(p.y)), p.size, p.size)
        painter.setPen(QPen(QColor(FG_COLOR))); painter.setFont(QFont("Quicksand", 28, QFont.Bold))
        painter.drawText(self.rect().adjusted(0, 150, 0, 0), Qt.AlignCenter, "PATCH SUCCESSFUL")
        painter.setPen(QPen(QColor(TEXT_DIM))); painter.setFont(QFont("Quicksand", 10))
        painter.drawText(self.rect().adjusted(0, 220, 0, 0), Qt.AlignCenter, "You may now close this window.")

# =============================================================================
# --- MAIN WINDOW ---
# =============================================================================


class ProgressPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(50, 0, 50, 0)
        layout.setSpacing(20)
        layout.setAlignment(Qt.AlignCenter)

        # Loading Label
        self.lbl_status = QLabel("INITIALIZING PATCH...")
        self.lbl_status.setAlignment(Qt.AlignCenter)
        self.lbl_status.setStyleSheet(f"font-size: 16pt; font-weight: bold; color: {TEXT_WHITE}; letter-spacing: 1px;")
        layout.addWidget(self.lbl_status)

        # Progress Bar
        self.pbar = QProgressBar()
        self.pbar.setFixedHeight(30)
        self.pbar.setTextVisible(False) # Hide the percentage text for a cleaner look
        self.pbar.setStyleSheet(f"""
            QProgressBar {{
                border: 2px solid #333;
                border-radius: 15px;
                background-color: #0F0F0F;
            }}
            QProgressBar::chunk {{
                background-color: {FG_COLOR};
                border-radius: 13px;
            }}
        """)
        layout.addWidget(self.pbar)

        # Percentage Label (Custom)
        self.lbl_percent = QLabel("0%")
        self.lbl_percent.setAlignment(Qt.AlignCenter)
        self.lbl_percent.setStyleSheet(f"font-size: 12pt; font-weight: bold; color: {FG_COLOR};")
        layout.addWidget(self.lbl_percent)

    def set_progress(self, val):
        self.pbar.setValue(val)
        self.lbl_percent.setText(f"{val}%")


class PatcherWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.config = CONFIG
        self.is_muted = False
        
        try:
            self.appdata_path = os.environ['LOCALAPPDATA']
            self.destination_dir = os.path.join(self.appdata_path, 'Packages', self.config['GAME_PACKAGE_ID'])
        except KeyError: self.destination_dir = None

        self.setup_ui()
        self.init_audio()

    def setup_ui(self):
        self.setWindowTitle("MS Patcher | Beach Buggy Racing")
        self.setFixedSize(550, 800)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)

        self.stack = QStackedWidget()
        main_layout.addWidget(self.stack)

        self.page_main = QWidget()
        self.setup_main_page()
        self.stack.addWidget(self.page_main)

        self.page_progress = ProgressPage()
        self.stack.addWidget(self.page_progress)
        
        self.page_success = ParticleWidget()
        self.stack.addWidget(self.page_success)

    def setup_main_page(self):
        layout = QVBoxLayout(self.page_main)
        layout.setContentsMargins(0, 0, 0, 0)

        # 1. HEADER ROW (Game Name + Speaker)
        header_widget = QWidget()
        header_layout = QHBoxLayout(header_widget)
        header_layout.setContentsMargins(30, 20, 30, 0)

        lbl_game = QLabel(self.config['GAME_NAME'])
        lbl_game.setStyleSheet(f"font-size: 22pt; font-weight: 800; color: {TEXT_WHITE};")
        header_layout.addWidget(lbl_game)

        header_layout.addStretch()

        self.btn_mute = VolumeButton()
        self.btn_mute.clicked.connect(self.toggle_music)
        header_layout.addWidget(self.btn_mute)

        layout.addWidget(header_widget)

        # 2. IMAGE (Ambient Style)
        img_label = FadedImageLabel(resource_path('game.png'))
        layout.addWidget(img_label)

        # 3. FEATURES BOX
        content_layout = QVBoxLayout()
        # Adjusted margins: Top 10, Bottom 10
        content_layout.setContentsMargins(40, 10, 40, 10)
        
        # Main container frame
        feat_frame = QFrame()
        feat_frame.setStyleSheet(f"""
            QFrame {{
                background-color: #0F0F0F;
                border-radius: 15px;
                border: 1px solid #333;
            }}
        """)
        
        # Shadow effect
        shadow_effect = QGraphicsDropShadowEffect()
        shadow_effect.setBlurRadius(20)
        shadow_effect.setColor(QColor(0, 255, 65, 30))
        shadow_effect.setOffset(0, 4)
        feat_frame.setGraphicsEffect(shadow_effect)

        # Layout for the list inside the box
        feat_layout = QVBoxLayout(feat_frame)
        feat_layout.setSpacing(15)  # Space between rows
        feat_layout.setContentsMargins(25, 25, 25, 35) # Bottom margin 35 for space
        
        # --- TITLE ---
        lbl_feat_title = QLabel("PATCH CONTENTS")
        lbl_feat_title.setAlignment(Qt.AlignCenter) 
        lbl_feat_title.setStyleSheet(f"""
            color: {FG_COLOR}; 
            font-weight: 900; 
            font-size: 11pt; 
            letter-spacing: 2px;
            border: none;
        """)
        feat_layout.addWidget(lbl_feat_title)
        
        # --- SEPARATOR ---
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("background-color: #333; border: none; max-height: 1px;")
        feat_layout.addWidget(line)
        feat_layout.addSpacing(5) 

        # --- ITEMS LOOP ---
        for feat in self.config['PATCH_FEATURES']:
            row_widget = QWidget()
            row_widget.setStyleSheet(f"""
                QWidget {{
                    background-color: #1A1A1A; 
                    border-radius: 8px;
                    border: 1px solid #252525;
                }}
            """)
            # IMPORTANT: Use setMinimumHeight instead of setFixedHeight
            # This prevents items from overlapping if space is tight
            row_widget.setMinimumHeight(45) 
            
            row_layout = QHBoxLayout(row_widget)
            row_layout.setContentsMargins(15, 0, 15, 0)
            row_layout.setSpacing(15)

            # Icon (Checkmark)
            icon_lbl = QLabel("✔")
            icon_lbl.setStyleSheet(f"""
                color: {FG_COLOR}; 
                font-size: 20px; 
                font-weight: 900; 
                border: none; 
                background: transparent;
            """)
            
            # Text
            text_lbl = QLabel(feat)
            text_lbl.setStyleSheet("color: #E0E0E0; font-size: 11pt; font-weight: 500; border: none; background: transparent;")
            
            row_layout.addWidget(icon_lbl)
            row_layout.addWidget(text_lbl)
            row_layout.addStretch() 
            
            feat_layout.addWidget(row_widget)

        content_layout.addWidget(feat_frame)
        layout.addLayout(content_layout)

        # 4. BIG PATCH BUTTON
        btn_container = QVBoxLayout()
        btn_container.setContentsMargins(50, 10, 50, 10)
        
        self.btn_patch = QPushButton("INITIALIZE PATCH")
        self.btn_patch.setObjectName("PatchButton")
        self.btn_patch.setFixedSize(400, 70)
        self.btn_patch.setCursor(Qt.PointingHandCursor)

        # Apply specific styling here to ensure the Hover effect is visible
        # Normal: Green Background, Black Text
        # Hover:  White Background, Green Text (High Contrast)
        self.btn_patch.setStyleSheet(f"""
            QPushButton {{
                background-color: {FG_COLOR};
                color: {BG_COLOR};
                border-radius: 35px;
                font-size: 22px;
                border: none;
                font-weight: 800;
                letter-spacing: 1px;
            }}
            QPushButton:hover {{
                background-color: #FFFFFF; /* Changes to White */
                color: {FG_COLOR};        /* Text becomes Green */
            }}
            QPushButton:pressed {{
                background-color: {ACCENT_COLOR};
                margin-top: 2px; /* Click effect */
            }}
        """)
        
        # Add Glow Shadow
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(30)
        shadow.setColor(QColor(FG_COLOR))
        shadow.setOffset(0, 0)
        self.btn_patch.setGraphicsEffect(shadow)
        
        self.btn_patch.clicked.connect(self.confirm_patch)
        
        btn_container.addWidget(self.btn_patch, alignment=Qt.AlignCenter)
        layout.addLayout(btn_container)

        # 5. FOOTER
        layout.addStretch()
        footer_layout = QHBoxLayout()
        footer_layout.setSpacing(15)
        
        btn_github = QPushButton("More Patches")
        btn_github.setObjectName("FooterButton")
        btn_github.setFixedSize(140, 40)
        btn_github.setCursor(Qt.PointingHandCursor)
        btn_github.clicked.connect(lambda: webbrowser.open(self.config['GITHUB_LINK']))
        
        btn_donate = QPushButton("Donate")
        btn_donate.setObjectName("FooterButton")
        btn_donate.setFixedSize(140, 40)
        btn_donate.setStyleSheet(f"border-color: {Qt.cyan}; color: cyan;")
        btn_donate.setCursor(Qt.PointingHandCursor)
        btn_donate.clicked.connect(lambda: webbrowser.open(self.config['DONATE_LINK']))

        footer_layout.addStretch()
        footer_layout.addWidget(btn_github)
        footer_layout.addWidget(btn_donate)
        footer_layout.addStretch()
        layout.addLayout(footer_layout)

        lbl_footer = QLabel("Developed by Someless | Use Responsibly")
        lbl_footer.setAlignment(Qt.AlignCenter)
        lbl_footer.setStyleSheet(f"color: {TEXT_DIM}; font-size: 8pt; margin-bottom: 15px;")
        layout.addWidget(lbl_footer)

    # --- LOGIC ---
    def init_audio(self):
        try:
            pygame.mixer.init()
            music_path = resource_path('music.mp3')
            if os.path.exists(music_path):
                pygame.mixer.music.load(music_path)
                pygame.mixer.music.play(loops=-1)
            else:
                self.btn_mute.setEnabled(False)
        except Exception as e:
            print(f"Audio Error: {e}")
            self.btn_mute.setEnabled(False)

    def toggle_music(self):
        if self.is_muted:
            pygame.mixer.music.unpause()
            self.btn_mute.set_muted(False)
            self.is_muted = False
        else:
            pygame.mixer.music.pause()
            self.btn_mute.set_muted(True)
            self.is_muted = True

    def confirm_patch(self):
        dlg = ModernDialog("Confirmation", 
                           "Please ensure the game is CLOSED.\n\nProceed with patching?", 
                           self)
        if dlg.exec_() == QDialog.Accepted:
            self.execute_patch()

    def execute_patch(self):
        # 1. Validation Checks First
        if not self.destination_dir:
            ModernDialog("Critical Error", "Could not find LOCALAPPDATA environment variable.", self, True).exec_()
            return

        if not os.path.isdir(self.destination_dir):
            dlg = ModernDialog("Game Not Found", 
                               f"Could not find '{self.config['GAME_NAME']}'.\nPlease install it from the Store.", 
                               self, True)
            if dlg.exec_() == QDialog.Accepted: 
                webbrowser.open(self.config['MS_STORE_LINK'])
            return

        # 2. Check source folders before starting
        for folder_name in self.config['FOLDERS_TO_COPY']:
            source_path = resource_path(os.path.join("Patch_folders", folder_name))
            if not os.path.isdir(source_path):
                ModernDialog("Error", f"Missing source folder: {folder_name}", self, True).exec_()
                return

        # 3. Validation Passed -> Switch to Progress Screen
        self.stack.setCurrentIndex(1) # Switch to Progress Page
        self.progress_val = 0
        self.page_progress.set_progress(0)
        self.page_progress.lbl_status.setText("PREPARING FILES...")
        
        # 4. Start Timer for Animation
        self.patch_timer = QTimer()
        self.patch_timer.timeout.connect(self.update_progress)
        self.patch_timer.start(30) # Speed of animation (lower = faster)

    def update_progress(self):
        self.progress_val += 1
        self.page_progress.set_progress(self.progress_val)

        # LOGIC: Do the actual file copy at 20% mark
        if self.progress_val == 20:
            self.page_progress.lbl_status.setText("WRITING DATA...")
            try:
                # Actual File Copy Operation
                for folder_name in self.config['FOLDERS_TO_COPY']:
                    source_path = resource_path(os.path.join("Patch_folders", folder_name))
                    target_path = os.path.join(self.destination_dir, folder_name)
                    if os.path.exists(target_path): 
                        shutil.rmtree(target_path)
                    shutil.copytree(source_path, target_path)
            except Exception as e:
                self.patch_timer.stop()
                self.stack.setCurrentIndex(0) # Go back to main
                ModernDialog("Patch Failed", f"Error during copy:\n{str(e)}", self, True).exec_()
                return

        # LOGIC: Update text at 80%
        if self.progress_val == 80:
            self.page_progress.lbl_status.setText("FINALIZING...")

        # LOGIC: Finished
        if self.progress_val >= 100:
            self.patch_timer.stop()
            self.stack.setCurrentIndex(2) # Switch to Success Page
            self.page_success.start_animation()

if __name__ == "__main__":
    if hasattr(Qt, 'AA_EnableHighDpiScaling'): QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    if hasattr(Qt, 'AA_UseHighDpiPixmaps'): QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication(sys.argv)
    app.setStyleSheet(STYLESHEET)
    icon_path = resource_path('icon.ico')
    if os.path.exists(icon_path): app.setWindowIcon(QIcon(icon_path))
    window = PatcherWindow()
    window.show()
    sys.exit(app.exec_())